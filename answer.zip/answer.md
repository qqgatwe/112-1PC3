# 第3次練習-練習-PC3
>
>學號：111111203
><br />
>姓名：張紋綺
><br />
>作業撰寫時間：20 (mins，包含程式撰寫時間)
><br />
>最後撰寫文件日期：2023/11/24
>

本份文件包含以下主題：(至少需下面兩項，若是有多者可以自行新增)
- [x] 說明內容
- [x] 個人認為完成作業須具備觀念

## 說明程式與內容

1.github建⽴⼀個名稱為FinalPorject112-1的倉庫<br>
2.在FinalPorject112-1的地方按settings:collaborators將組員加進來<br>
3.組員會收到email連結點進去就可以有FinalPorject112-1的倉庫<br>
4.先建立一個檔案index.html、add、commit及push<br>
5.gir branch 自己的分支和組員分支<br>
6.git checkout 自己的分支和組員分支，建立txt檔案，打上內容，之後再commit和push<br>


## 個人認為完成作業須具備觀念

先了解如何建立倉庫，學習到要怎麼建立自己和組員的分支，在如何切換建立的分支，之後要add、commit和push上去，這次作業讓我了解到很多。